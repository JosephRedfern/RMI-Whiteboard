import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;

/**
 * Created by joe on 10/03/15.
 */
public class WhiteboardClientGUI implements IWhiteboardItemListener{

    IWhiteboardClient client;
    private JPanel panel1;
    private JPanel boardContainer;
    private JButton getShapes;
    private JButton randomButton;
    private JPanel buttonContainer;
    private JButton clearMineButton;
    private WhiteboardPanel panel;

    public WhiteboardClientGUI(IWhiteboardClient client) throws RemoteException{
        JFrame frame = new JFrame();
        this.client = client;
        client.addItemListener(this);

        getShapes.addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent e){
                                                WhiteboardClientGUI.this.resync();
                                            }
                                        });

        randomButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int maxX = WhiteboardClientGUI.this.panel.getWidth();
                int maxY = WhiteboardClientGUI.this.panel.getHeight();

                int X = (int) Math.abs(Math.round(Math.random() * maxX));
                int Y = (int) Math.abs(Math.round(Math.random() * maxY));

                try {
                    WhiteboardClientGUI.this.client.getContext().addShape(new Rectangle(X, Y, 50, 50));
                }catch(RemoteException err){
                    err.printStackTrace();
                }
            }
        });

        panel = new WhiteboardPanel(client.getContext().getShapes());
        boardContainer.add(panel);

        frame.add(panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setSize(200, 200);
        clearMineButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    WhiteboardClientGUI.this.client.getContext().clearShapes();
                }catch(RemoteException err){
                    err.printStackTrace();
                }
            }
        });
    }

    public void receiveShape(IWhiteboardItem item){
        panel.addItem(item);
        System.out.println("~~~~~~~~~~~~> GOT SHAPE (in WhiteboardClientGUI)!!!");
    }

    public void resync(){
        try {
            panel.updateShapes(this.client.getContext().getShapes());
        }catch(RemoteException err){
            err.printStackTrace();
        }
    }
}
